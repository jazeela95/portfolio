export const items=[
{
    name:"saalim",
    email:"salaam@gmail.com",
    phone:"8754336879"

},
{
    name:"kamar",
    email:"salaam@gmail.com",
    phone:"8754336879"

},
{
    name:"ajaaf",
    email:"salaam@gmail.com",
    phone:"8754336879"

}



]